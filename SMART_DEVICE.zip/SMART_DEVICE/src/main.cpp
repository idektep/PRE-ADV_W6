#include <Arduino.h>
#include <WiFi.h>
#include <PubSubClient.h>


// === include DHT
// === include BH1750


#include <ArduinoJson.h>
#include "config.h"

// ─────────────────────────────────────────
//  Objects
// ─────────────────────────────────────────





WiFiClient   wifiClient;
PubSubClient mqtt(wifiClient);

// ─────────────────────────────────────────
//  State
// ─────────────────────────────────────────
unsigned long lastPublish  = 0;
bool          ledLightOn   = false;
bool          ledFanOn     = false;

// ============================================================
//  ── Prototypes ──
// ============================================================
void connectWiFi();
void connectMQTT();
void mqttCallback(char* topic, byte* payload, unsigned int len);
void readAndPublish();
void publishFloat(const char* topic, float value, uint8_t decimals);
void publishStr(const char* topic, const char* value, bool retain = false);
String extractValue(const String& json);
void setLight(bool on);
void setFan(bool on);

// ============================================================
//  SETUP
// ============================================================
void setup() {
  Serial.begin(115200);
  delay(200);
  Serial.println("\n╔══════════════════════════════╗");
  Serial.println("║  ESP32 IoT Dashboard v2.0    ║");
  Serial.println("╚══════════════════════════════╝");

  // ── GPIO ──




  // ── I2C ──





  // ── DHT22 ──




  // ── BH1750 ──















  //==========================================================================================
  // ── WiFi ──
  connectWiFi();
  // ── MQTT ──
  mqtt.setServer(MQTT_BROKER, MQTT_PORT);
  mqtt.setCallback(mqttCallback);
  mqtt.setKeepAlive(60);
  connectMQTT();

  Serial.println("[INIT] พร้อมทำงาน ✓\n");
}

// ============================================================
//  LOOP
// ============================================================
void loop() {
  if (!mqtt.connected()) {
    connectMQTT();
  }
  mqtt.loop();

  unsigned long now = millis();
  if (now - lastPublish >= PUBLISH_INTERVAL_MS) {
    lastPublish = now;
    readAndPublish();
  }
}

// ============================================================
//  WiFi
// ============================================================
void connectWiFi() {
  Serial.printf("[WiFi] กำลังเชื่อมต่อ \"%s\"", WIFI_SSID);
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  uint8_t retry = 0;
  while (WiFi.status() != WL_CONNECTED && retry < 40) {
    delay(500);
    Serial.print(".");
    retry++;
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.printf("\n[WiFi] ✓ Connected  IP: %s\n", WiFi.localIP().toString().c_str());
  } else {
    Serial.println("\n[WiFi] ✗ Failed — Restarting...");
    delay(1000);
    ESP.restart();
  }
}

// ============================================================
//  MQTT Connect
// ============================================================
void connectMQTT() {
  Serial.printf("[MQTT] กำลังเชื่อมต่อ %s:%d ...", MQTT_BROKER, MQTT_PORT);

  uint8_t retry = 0;
  while (!mqtt.connected() && retry < 5) {
    bool ok;
    if (strlen(MQTT_USER) > 0) {
      ok = mqtt.connect(MQTT_CLIENT_ID, MQTT_USER, MQTT_PASS);
    } else {
      ok = mqtt.connect(MQTT_CLIENT_ID);
    }

    if (ok) {
      Serial.println(" ✓");
      // Subscribe คำสั่งจาก Dashboard
      mqtt.subscribe(TOPIC_CMD_LIGHT, 1);
      mqtt.subscribe(TOPIC_CMD_FAN,   1);
      Serial.println("[MQTT] Subscribed: control/light, control/fan");
      publishStr(TOPIC_STATUS, "online", true);
    } else {
      Serial.printf(" ✗ (rc=%d) — รอ 3s\n", mqtt.state());
      delay(3000);
      retry++;
    }
  }
}
// ============================================================
//  MQTT Callback — รับคำสั่งจาก Dashboard
// ============================================================
void mqttCallback(char* topic, byte* payload, unsigned int len) {
  char buf[len + 1];
  memcpy(buf, payload, len);
  buf[len] = '\0';
  String msg   = String(buf);
  String t     = String(topic);
  String val   = extractValue(msg);
  bool   turnOn = (val == "ON" || val == "1" || val == "true");

  Serial.printf("[MQTT] ← %s : %s\n", topic, msg.c_str());

  if (t == TOPIC_CMD_LIGHT) {
    setLight(turnOn);
  } else if (t == TOPIC_CMD_FAN) {
    setFan(turnOn);
  }
}

// ============================================================







//  อ่านเซ็นเซอร์และส่ง MQTT
// ============================================================
void readAndPublish() {
  Serial.println("┌─── Read Sensors ───────────────");

















  
  Serial.println("└────────────────────────────────\n");
}

// ============================================================
//  Helpers
// ============================================================

// ส่งค่า float เป็น JSON {"value": X}
void publishFloat(const char* topic, float value, uint8_t decimals) {
  char payload[48];
  if (decimals == 0)      snprintf(payload, sizeof(payload), "{\"value\":%.0f}", value);
  else if (decimals == 1) snprintf(payload, sizeof(payload), "{\"value\":%.1f}", value);
  else                    snprintf(payload, sizeof(payload), "{\"value\":%.2f}", value);
  mqtt.publish(topic, payload, false);
}

// ส่งค่า string เป็น JSON {"value": "X"}
void publishStr(const char* topic, const char* value, bool retain) {
  char payload[64];
  snprintf(payload, sizeof(payload), "{\"value\":\"%s\"}", value);
  mqtt.publish(topic, payload, retain);
}

// ดึง value จาก JSON string {"value":"..."}
String extractValue(const String& json) {
  JsonDocument doc; // เปลี่ยนจาก StaticJsonDocument<128> doc;
  
  if (!deserializeJson(doc, json) && doc.containsKey("value")) {
    return doc["value"].as<String>();
  }
  
  // Fallback: plain text เช่น "ON", "OFF"
  String s = json;
  s.trim();
  return s;
}


//── ควบคุมไฟห้อง ──
void setLight(bool on) {
   //____________________________
   //____________________________
  


  publishStr("sensors/device/light_state", on ? "ON" : "OFF");
  Serial.printf("[CTRL] 💡 ไฟห้อง → %s\n", on ? "ON" : "OFF");
}

// ── ควบคุมพัดลม ──
void setFan(bool on) {
 
  //____________________________
  //____________________________

  publishStr("sensors/device/fan_state", on ? "ON" : "OFF");
  Serial.printf("[CTRL] 🌀 พัดลม  → %s\n", on ? "ON" : "OFF");
}
